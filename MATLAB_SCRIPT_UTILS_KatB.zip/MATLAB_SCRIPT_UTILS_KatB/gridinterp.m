clc;
clear;


% open excel file
[data]=readmatrix('CWG_Ceiling_10_Drip_logger_16_and_17_clean.txt');

x = data(:,1);
y = data(:,2);
z = data(:,3);
[t,r] = cart2pol(x,y);
rr = linspace(min(r),max(r),20);
tt = linspace(0,2*pi,20);
[T,R] = meshgrid(tt,rr);            % new mesh
[X,Y] = pol2cart(T,R);              % convert new mesh to cartesian
Z = griddata(x,y,z,X,Y);            % according Z coordinates

figure(1);clf;
plot3(x,y,z);
hold on;
surf(X,Y,Z);
axis tight
shading interp
colorbar
% % 
% figure(1);
% plot3(x, y, z, '.')