function params=ReadParamsFile(filename)

% See DS user guide for functions documentation

% Written by Gregoire Mariethoz, 2010

fid=fopen(filename,'r');
if fid==-1
    disp('cannot open params.dat file')
    return
end

%METHOD
SkipComments(fid);
params.method=fscanf(fid,'%s',1);

if (strcmp(params.method,'MERGE'))
    %SkipComments(fid);
    params.parentsfile=fscanf(fid,'%s',1);
    
    %SkipComments(fid);
    params.fract_merged=fscanf(fid,'%s',1);
    
    %SkipComments(fid);
    params.thr_merge=fscanf(fid,'%s',1);
end

%FILES
SkipComments(fid);
params.ti_file=fscanf(fid,'%s',1);

SkipComments(fid);
params.angles_file=fscanf(fid,'%s',1);
if (strcmp(params.angles_file,'unif'))
    params.unifanglex=str2double(fscanf(fid,'%s',1));   
    params.unifangley=str2double(fscanf(fid,'%s',1));  
    params.unifanglez=str2double(fscanf(fid,'%s',1));    
    params.tolunifanglex=str2double(fscanf(fid,'%s',1));   
    params.tolunifangley=str2double(fscanf(fid,'%s',1));  
    params.tolunifanglez=str2double(fscanf(fid,'%s',1));     
end

SkipComments(fid);
params.affinity_file=fscanf(fid,'%s',1);
if (strcmp(params.affinity_file,'unif'))
    params.uniaffinityx=str2double(fscanf(fid,'%s',1));  
    params.uniaffinityy=str2double(fscanf(fid,'%s',1));     
    params.uniaffinityz=str2double(fscanf(fid,'%s',1));  
    params.toluniaffinityx=str2double(fscanf(fid,'%s',1));  
    params.toluniaffinityy=str2double(fscanf(fid,'%s',1));     
    params.toluniaffinityz=str2double(fscanf(fid,'%s',1));    
end

SkipComments(fid);
params.condit_data_file=fscanf(fid,'%s',1);

%SkipComments(fid);
%params.connectivity_data_file=fscanf(fid,'%s',1);

SkipComments(fid);
params.prefix=fscanf(fid,'%s',1);

SkipComments(fid);
params.vtk_prefix=fscanf(fid,'%s',1);

SkipComments(fid);
params.report_prefix=fscanf(fid,'%s',1);

%PARALLELIZATION - skip this line to avoid problems for CPU/GPU input files
SkipComments(fid);
params.parallelization=str2double(fscanf(fid,'%s',1));

%REALIZATIONS
SkipComments(fid);
params.nb_realz=str2double(fscanf(fid,'%s',1));

%GRID
SkipComments(fid);
params.nb_cells_x=str2double(fscanf(fid,'%s',1));
params.nb_cells_y=str2double(fscanf(fid,'%s',1));
params.nb_cells_z=str2double(fscanf(fid,'%s',1));

SkipComments(fid);
params.cells_size_x=str2double(fscanf(fid,'%s',1));
params.cells_size_y=str2double(fscanf(fid,'%s',1));
params.cells_size_z=str2double(fscanf(fid,'%s',1));

SkipComments(fid);
params.grid_origin_x=str2double(fscanf(fid,'%s',1));
params.grid_origin_y=str2double(fscanf(fid,'%s',1));
params.grid_origin_z=str2double(fscanf(fid,'%s',1));

%NEIGHBORHOOD
SkipComments(fid);
params.max_search_distance_x=str2double(fscanf(fid,'%s',1));
params.max_search_distance_y=str2double(fscanf(fid,'%s',1));
params.max_search_distance_z=str2double(fscanf(fid,'%s',1));

SkipComments(fid);
params.anisotropy_ratio_x=str2double(fscanf(fid,'%s',1));
params.anisotropy_ratio_y=str2double(fscanf(fid,'%s',1));
params.anisotropy_ratio_z=str2double(fscanf(fid,'%s',1));

%DS PARAMETERS
SkipComments(fid);
params.t=str2double(fscanf(fid,'%s',1));

SkipComments(fid);
params.f=str2double(fscanf(fid,'%s',1));

%TRANSFORMATIONS
SkipComments(fid);
params.rotations_operation=str2double(fscanf(fid,'%s',1));

SkipComments(fid);
params.affinity_operation=str2double(fscanf(fid,'%s',1));

%PATH
SkipComments(fid);
params.path=str2double(fscanf(fid,'%s',1));

%CONNECTIVITY
% SkipComments(fid);
% params.use_connectivity=str2double(fscanf(fid,'%s',1));
% params.connectivity_variable=str2double(fscanf(fid,'%s',1));
% params.nb_neighbors_connectivity=str2double(fscanf(fid,'%s',1));
% params.weight_connectivity=str2double(fscanf(fid,'%s',1));
% params.conncectivity_strategy=str2double(fscanf(fid,'%s',1));

%VARIABLES
SkipComments(fid);
params.nb_variables=str2double(fscanf(fid,'%s',1));

SkipComments(fid);
for i=1:params.nb_variables
    params.var_type(1,i)=str2double(fscanf(fid,'%s',1));
end

SkipComments(fid);
for i=1:params.nb_variables
    params.var_weight(1,i)=str2double(fscanf(fid,'%s',1));
end

SkipComments(fid);
for i=1:params.nb_variables
    params.weight_condit_data(1,i)=str2double(fscanf(fid,'%s',1));
end

SkipComments(fid);
for i=1:params.nb_variables
    params.n(1,i)=str2double(fscanf(fid,'%s',1));
end

SkipComments(fid);
for i=1:params.nb_variables
    params.d(1,i)=str2double(fscanf(fid,'%s',1));
end

%SCAN INTERRUPTION
% SkipComments(fid);
% for i=1:params.nb_variables
%     params.Si_param1(1,i)=str2double(fscanf(fid,'%s',1));
%     params.Si_param2(1,i)=str2double(fscanf(fid,'%s',1));
% end

%SYN-PROCESSING
SkipComments(fid);
params.syn_pro_max=str2double(fscanf(fid,'%s',1));
params.syn_pro_degree_decreasing=str2double(fscanf(fid,'%s',1));
params.syn_pro_restore=str2double(fscanf(fid,'%s',1));
params.syn_pro_reject=str2double(fscanf(fid,'%s',1));

%POST-PROCESSING
SkipComments(fid);
params.post_pro_nb_passes=str2double(fscanf(fid,'%s',1));
params.post_pro_factor=str2double(fscanf(fid,'%s',1));

%PARAMETERS REDUCTION
SkipComments(fid);
params.Pr=str2double(fscanf(fid,'%s',1));

%SEED
SkipComments(fid);
params.seed=str2double(fscanf(fid,'%s',1));

SkipComments(fid);
params.display_param_1=str2double(fscanf(fid,'%s',1));
params.display_param_2=str2double(fscanf(fid,'%s',1));

fclose(fid);
