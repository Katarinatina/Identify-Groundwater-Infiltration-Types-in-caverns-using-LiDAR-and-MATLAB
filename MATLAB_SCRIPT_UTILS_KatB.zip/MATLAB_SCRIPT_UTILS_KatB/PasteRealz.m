function PasteRealz(prefix,start,finish)

% See DS user guide for functions documentation

% Written by Gregoire Mariethoz, 2010

allsims=[];
allnamevar='';

totalnbvar=0;
for c=start:finish   
    filename=[prefix,'_realz_',num2str(c),'.SGEMS'];
    [sim,x,y,z,nbvar,namevar]=LoadGrid(filename);
    totalnbvar=totalnbvar+nbvar;
    
    %first file: remember dimensions
    if c==start
        x1=x;y1=y;z1=z;
    %next files: check that dimensions are the same
    else
        if (x~=x1 || y~=y1 || z~=z1)
            disp(['Dimensions of file # ',num2str(c),' do not match'])
            return
        end
    end
    
    %sim=YXZ2XYZ(sim);
    sim=reshape(sim,x*y*z,nbvar);
    allsims=[allsims sim];
    namevar=strcat(namevar,['_realz_',num2str(c)]);
    allnamevar=[allnamevar namevar];
end

allsims=reshape(allsims,x,y,z,totalnbvar);
filename=[prefix,'_realz_',num2str(start),'_to_',num2str(finish),'.SGEMS'];
WriteGrid(allsims,filename,allnamevar);

