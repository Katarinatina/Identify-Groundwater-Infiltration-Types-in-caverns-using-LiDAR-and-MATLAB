figure(12); clf;
scatter(length, Aspect_Ratio, 'red', 'filled')
xlim([0 100])
ylim([0 40])
title('site 1')
xlabel('Stalactite length (cm)')