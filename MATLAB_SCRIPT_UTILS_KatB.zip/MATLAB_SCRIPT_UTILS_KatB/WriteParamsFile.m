% Function: WriteParamsFile
% Usage: WriteParamsFile(params,filename)
% -----------------------------------------
% Input: param - A struct of the form resulting from calling ReadParamsFile
%       filename - name of new parameter file

% Matz Haugen and Gregoire Mariethoz, Stanford University, 2010


function WriteParamsFile(params,filename)

fid = fopen(filename,'wt');

fprintf(fid,'%s\n', '/******************************************************************************');
fprintf(fid,'%s\n', 'THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" ');
fprintf(fid,'%s\n', 'AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED');
fprintf(fid,'%s\n', 'WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.');
fprintf(fid,'%s\n', 'IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,');
fprintf(fid,'%s\n', 'INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,');
fprintf(fid,'%s\n', 'BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, ');
fprintf(fid,'%s\n', 'DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY ');
fprintf(fid,'%s\n', 'OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE');
fprintf(fid,'%s\n', 'OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED');
fprintf(fid,'%s\n', 'OF THE POSSIBILITY OF SUCH DAMAGE.');
fprintf(fid,'%s\n', '******************************************************************************/');
fprintf(fid,'%s\n', '');
fprintf(fid,'%s\n', '                  /*** Use C-style comments in this file ***/');
fprintf(fid,'%s\n', '/*** FILE GENERATED WITH WriteParamsFile.m SEE USER MANUAL AND PhD THESIS FOR MEANING OF THE PARAMETERS ***/');

fprintf(fid,'%s\n', '');

%METHOD
fprintf(fid,'%s\n', '//METHOD');
fprintf(fid,'  %s      ',params.method);

if (strcmp(params.method,'MERGE'))
    fprintf(fid,' %s  ',params.parentsfile);
    fprintf(fid,' %s  ',params.fract_merged);
    fprintf(fid,' %s  ',params.thr_merge);    
end

fprintf(fid,'%s\n','      // Simulation method');

%FILES
fprintf(fid,'\n%s\n', '//FILES');
fprintf(fid,'  %s',params.ti_file);
fprintf(fid,'%s\n','      // File containing training images.');
fprintf(fid,'  %s',params.angles_file);

if (strcmp(params.angles_file,'unif'))
    fprintf(fid,' %s ',num2str(params.unifanglex));
    fprintf(fid,' %s ',num2str(params.unifangley));
    fprintf(fid,' %s ',num2str(params.unifanglez));
    fprintf(fid,' %s ',num2str(params.tolunifanglex));
    fprintf(fid,' %s ',num2str(params.tolunifangley));
    fprintf(fid,' %s ',num2str(params.tolunifanglez));
end

fprintf(fid,'%s\n','      // File containing angles map.');
fprintf(fid,'  %s',params.affinity_file);

if (strcmp(params.affinity_file,'unif'))
    fprintf(fid,' %s ',num2str(params.uniaffinityx));
    fprintf(fid,' %s ',num2str(params.uniaffinityy));
    fprintf(fid,' %s ',num2str(params.uniaffinityz));
    fprintf(fid,' %s ',num2str(params.toluniaffinityx));
    fprintf(fid,' %s ',num2str(params.toluniaffinityy));
    fprintf(fid,' %s ',num2str(params.toluniaffinityz));    
end

fprintf(fid,'%s\n','      // File containing affinity maps.');
fprintf(fid,'  %s',params.condit_data_file);
fprintf(fid,'%s\n','      // File containing conditioning data points.');
fprintf(fid,'  %s',params.prefix);
fprintf(fid,'%s\n','      // Prefix for the simulation output files.');
fprintf(fid,'  %s',params.vtk_prefix);
fprintf(fid,'%s\n','      // Prefix for the vtk (paraview) file.');
fprintf(fid,'  %s',params.report_prefix);
fprintf(fid,'%s\n','      // Prefix for the file name for the report.');

%PARALLELIZATION
fprintf(fid,'\n%s\n', '//PARALLELIZATION ');

fprintf(fid,'  %s',num2str(params.parallelization));
fprintf(fid,'%s\n','      // OpenMP version: number of threads.');

%REALIZATIONS
fprintf(fid,'%s\n', '//REALIZATIONS   ');
fprintf(fid,'  %s       // Number of realizations.\n',num2str(params.nb_realz));

%GRID
fprintf(fid,'\n%s\n', '//GRID   ');
fprintf(fid,'  %s  %s  %s      // Number of cells in simulation grid (x,y,z).\n',num2str(params.nb_cells_x),num2str(params.nb_cells_y),num2str(params.nb_cells_z));
fprintf(fid,'  %s  %s  %s      // Size of cells (x,y,z).\n',num2str(params.cells_size_x),num2str(params.cells_size_y),num2str(params.cells_size_z));
fprintf(fid,'  %s  %s  %s      // Origin of simulation grid (x,y,z).\n',num2str(params.grid_origin_x),num2str(params.grid_origin_y),num2str(params.grid_origin_z));

%NEIGHBORHOOD
fprintf(fid,'\n%s\n', '//NEIGHBORHOOD   ');
fprintf(fid,'  %s  %s  %s      // Maximum search distance (x,y,z).\n',num2str(params.max_search_distance_x),num2str(params.max_search_distance_y),num2str(params.max_search_distance_z));
fprintf(fid,'  %s  %s  %s      // Anisotropy ratios in the search radius(x,y,z).\n',num2str(params.anisotropy_ratio_x),num2str(params.anisotropy_ratio_y),num2str(params.anisotropy_ratio_z));

%DS PARAMETERS
fprintf(fid,'\n%s\n', '//DS PARAMETERS   ');
fprintf(fid,'  %s        ',num2str(params.t));
fprintf(fid,'%s\n', '      // Threshold position, between 0 and 1. -1 for automatic threshold.');
fprintf(fid,'  %s        ',num2str(params.f));
fprintf(fid,'%s\n', '      // Max. fraction of the TI to scan.');

%TRANSFORMATIONS
fprintf(fid,'\n%s\n', '//TRANSFORMATIONS   ');
fprintf(fid,'  %s        ',num2str(params.rotations_operation));
fprintf(fid,'%s\n', '      // Use of rotations.');
fprintf(fid,'  %s        ',num2str(params.affinity_operation));
fprintf(fid,'%s\n', '      // Use of affinity.');

%PATH
fprintf(fid,'\n%s\n', '//PATH   ');
fprintf(fid,'  %s        ',num2str(params.path));
fprintf(fid,'%s\n', '      // Path type.');

%CONNECTIVITY
% fprintf(fid,'\n%s\n', '//CONNECTIVITY     ');
% for i = 32:36
% fprintf(fid,'  %s ',num2str(c{i}));
% end
%
% fprintf(fid,'%s\n', '          // Connectivity parameters. 5 values:');
% fprintf(fid,'%s\n', '                    //    A: Use connectivity measure (0=no, 1=yes).');
% fprintf(fid,'%s\n', '                    //    B: The variable id on which connectivity has to be measured (first variable is 0, then 1,...). Facies codes has to start with 0.');
% fprintf(fid,'%s\n', '                    //    C: Number of neighbors for measuring connectivity.');
% fprintf(fid,'%s\n', '                    //    D: Weight of conditioning to connectivity regarding other constraints.');
% fprintf(fid,'%s\n', '                    //    E: 0: only consider the input data points for connectivity.');
% fprintf(fid,'%s\n', '                    //       1: keep updated a geobodys map for the simulation and consider the connectivity in the entire data event.');

%VARIABLES
fprintf(fid,'\n%s\n', '//VARIABLES    ');
fprintf(fid,'  %s ',num2str(params.nb_variables));
fprintf(fid,'%s\n','      // Number of variables to simulate jointly.');

for i=1:params.nb_variables
    fprintf(fid,'  %s ',num2str(params.var_type(i)));
end
fprintf(fid,'%s\n', '      // Type of each variable.');
for i=1:params.nb_variables
    fprintf(fid,'  %s ',num2str(params.var_weight(i)));
end
fprintf(fid,'%s\n', '      // Relative weight of each variable.');

for i=1:params.nb_variables
    fprintf(fid,'  %s ',num2str(params.weight_condit_data(i)));
end
fprintf(fid,'%s\n', '      // Weight of conditioning data for each variable.');

for i=1:params.nb_variables
    fprintf(fid,'  %s ',num2str(params.n(i)));
end
fprintf(fid,'%s\n', '      // Maximum number of points in neighborhood for each simulated variable.');

for i=1:params.nb_variables
    fprintf(fid,'  %s ',num2str(params.d(i)));
end
fprintf(fid,'%s\n', '      // Exponent of the distance function in the template for each variable.');

%SCAN INTERRUPTION
% fprintf(fid,'\n%s\n', '//SCAN INTERRUPTION   ');
% for i = 43:44
%     fprintf(fid,'  %s ',num2str(c{i}));
% end
% fprintf(fid,'%s\n', '           // Parameters of scan interruption. 2 values per variable.');
% fprintf(fid,'%s\n', '                                       //    A: Min. fraction of matching nodes in TI data event per variable.');
% fprintf(fid,'%s\n', '                                       //    B:
% Relevant only in case of continuous variable. Fraction of the max. dist. for this variable under which a neighbor node is considered as matching.');

%SYN-PROCESSING
fprintf(fid,'\n%s\n', '//SYN-PROCESSING');
fprintf(fid,'  %s ',num2str(params.syn_pro_max));
fprintf(fid,'  %s ',num2str(params.syn_pro_degree_decreasing));
fprintf(fid,'  %s ',num2str(params.syn_pro_restore));
fprintf(fid,'  %s ',num2str(params.syn_pro_reject));

fprintf(fid,'%s\n', '      // Syn-processing parameters. 4 values');

%POST-PROCESSING
fprintf(fid,'\n%s\n', '//POST-PROCESSING');
fprintf(fid,'  %s ',num2str(params.post_pro_nb_passes));
fprintf(fid,'  %s ',num2str(params.post_pro_factor));
fprintf(fid,'%s\n', '      // Post-processing parameters. 2 values.');

%PARAMETERS REDUCTION
fprintf(fid,'\n%s\n', '//PARAMETERS REDUCTION');
fprintf(fid,'  %s ',num2str(params.Pr));
fprintf(fid,'%s\n', '      // Moment when parameters reduction takes place.');

%MISC
fprintf(fid,'\n%s\n', '//MISC   ');
fprintf(fid,'  %s ',num2str(params.seed));
fprintf(fid,'%s\n', '      // Initial random seed.');

fprintf(fid,'  %s ',num2str(params.display_param_1));
fprintf(fid,'  %s ',num2str(params.display_param_2));

fprintf(fid,'%s\n', '      // Display options. 2 values:');
fprintf(fid,'\n%s', 'END   ') ;

fclose(fid);