function [ReducedModel,FullModel]=SLR(x,Y)
 
m = size(x,2);
 
%% Fit a logistic regression model to the data using all predictors
[b,dev,stats]  =   glmfit(x,Y,'binomial');
 
disp('Full model')
disp(['   Coeff.   ' 'Std. Err' '   Z Score'])
disp([  stats.beta...
    stats.se...
    (stats.beta./ stats.se)])
 
FullModel   =   [  stats.beta...
    stats.se...
    (stats.beta./ stats.se)];
 
%% sequential feature selection
 
[in,history] = sequentialfs(@fitter,x,Y,'cv','none',...
    'nfeatures',m,'nullmodel',true);
 
dev         =   history.Crit    % set of deviance values for all models
deltadev    =   -diff(dev);     % deviance improvement for each step
 
% Under the null hypothesis 2*deviance has a chi-square distribution, so
% we'll take the chi-square cutoff and divide by 2.
maxdev      =   chi2inv(.95,1)/2;
nfeatures   =   find(deltadev>maxdev,1,'last');
 
if isempty(nfeatures)
    nfeatures = 0;
    in = false(1,m);
else
    in = logical(history.In(nfeatures,:));
end
 
% Plot all deviance values and mark the one we'd select
plot((1:m)',dev(2:end),'b-x', nfeatures,dev(nfeatures+1),'ro')
[b,dev,stats]   =   glmfit(x(:,in),Y,'binomial');
xlabel('Number of predictors'); ylabel('Deviance')
 
% Display the coefficients for the selected model
 
B               =   zeros(2,m+1);
B(1,[true,in])  =   b';
B(2,[true,in])  =   stats.se';
B(3,[true,in])  =   (stats.beta./ stats.se)';
ReducedModel    =   B';
disp('Reduced model')
disp(B')
 
function dev = fitter(x,y)
[b,dev] = glmfit(x,y,'binomial');
