% open excel file
[data]=readmatrix('THMK_10.txt');

% read X, Y, Z values
x = data(:,1); % X coordinates (meters)
y = data(:,2); % Y coordinates (meters)
z = data(:,3); % Z coordinates (meters)

xlin = linespace(min(x), max(x), size(x));
ylin = linespace(min(y), max(y), size(y));
[X,Y] = meshgrid(xlin, ylin);
Z = griddata(x,y,z, X,Y, 'natural');
mesh(X,Y,Z)
axis tight