function G=ComputeG(grid,var)

% See DS user guide for functions documentation

% Written by Gregoire Mariethoz, 2010

%% keep only desired variable
grid=grid(:,:,:,var);

%% make sure the grid is ok
x=size(grid,1);
y=size(grid,2);
z=size(grid,3);

if min(grid)~=0
    disp('Facies must start with 0')
    return
end

checkint=sum((round(grid)-grid).^2);
if sum(checkint)~=0
    disp('The grid must be populated with facies')
    return
end

nf=max(grid(:))+1;

%% save grid in column format
grid=reshape(grid,x*y*z,1);
save -ascii tmp grid

%% run connectivity function
command=['..\..\utils\MATLAB_BIN_UTILS\Gconnect.exe tmp ',num2str(x),' ',num2str(y),' ',num2str(z),' ',num2str(nf),' > tmp2'];
system(command);

fid=fopen('tmp2','r');
%pass filename
dummy=fscanf(fid,'%s',1);
%pass proportions
for i=1:nf
    dummy=fscanf(fid,'%s',1);
end
%G
G=zeros(nf,1);
for i=1:nf
    G(i)=str2num(fscanf(fid,'%s',1));
end
fclose(fid);

delete('tmp');
delete('tmp2');


